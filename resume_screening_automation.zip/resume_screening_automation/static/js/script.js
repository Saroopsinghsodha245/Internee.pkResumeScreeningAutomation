/* Resume Screening Automation — frontend logic
   Handles: file upload / dropzone, JD templates, calling /api/analyze,
   rendering ranked candidate cards with animated score rings, CSV export. */

(() => {
  const dropzone = document.getElementById('dropzone');
  const fileInput = document.getElementById('fileInput');
  const fileListEl = document.getElementById('fileList');
  const runBtn = document.getElementById('runBtn');
  const jdTextarea = document.getElementById('jobDescription');
  const errorMsg = document.getElementById('errorMsg');

  const emptyState = document.getElementById('emptyState');
  const loadingState = document.getElementById('loadingState');
  const resultsState = document.getElementById('resultsState');
  const loadingText = document.getElementById('loadingText');
  const resultsList = document.getElementById('resultsList');
  const resultCount = document.getElementById('resultCount');
  const jdSummary = document.getElementById('jdSummary');
  const exportBtn = document.getElementById('exportBtn');
  const engineBadge = document.getElementById('engineBadge');
  const engineLabel = document.getElementById('engineLabel');

  let selectedFiles = [];
  let currentSessionId = null;

  const JD_TEMPLATES = {
    ml: `Machine Learning Intern

We are looking for a Machine Learning Intern to help automate and improve our internal tooling.

Responsibilities:
- Extract structured information (skills, experience) from unstructured text using spaCy or NLTK
- Build and evaluate matching models using TF-IDF and BERT embeddings
- Work with Pandas/NumPy/scikit-learn for data processing and model evaluation
- Collaborate with the engineering team on Python-based automation scripts

Requirements:
- Strong Python programming skills
- Familiarity with Machine Learning, NLP, and Data Analysis
- Experience with scikit-learn, spaCy or NLTK
- Understanding of Data Structures and Algorithms
- 0-2 years of experience; internship or academic project experience welcome`,

    fullstack: `Full-Stack Developer

We're hiring a Full-Stack Developer to build and ship features across our web platform.

Responsibilities:
- Build REST APIs using Flask or Django
- Develop responsive front-ends with React and Tailwind CSS
- Design and manage PostgreSQL / MongoDB schemas
- Deploy and monitor services on AWS with Docker and CI/CD

Requirements:
- Proficiency in JavaScript, Python, and SQL
- Experience with React, Node.js, and REST API design
- Familiarity with Git, Docker, and cloud platforms (AWS/Azure)
- 2+ years of experience in web development
- Bachelor's degree in Computer Science or related field`,

    data: `Data Analyst

We are seeking a Data Analyst to turn raw data into actionable insights.

Responsibilities:
- Clean and analyze large datasets using Python (Pandas, NumPy)
- Build dashboards and visualizations using Power BI or Tableau
- Write SQL queries to extract data from relational databases
- Present findings to stakeholders with clear data visualization

Requirements:
- Strong skills in SQL, Excel, and Python
- Experience with Data Visualization tools (Power BI, Tableau, Matplotlib)
- Analytical Skills and attention to detail
- 1+ years of experience in a data-related role`
  };

  document.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => {
      jdTextarea.value = JD_TEMPLATES[chip.dataset.template] || '';
      validateForm();
    });
  });

  // ---------------- Engine badge (BERT vs TF-IDF only) ----------------
  const bertAvailable = document.body.dataset.bert === 'true';
  // read from a data attribute injected by Flask via inline script below
  window.addEventListener('DOMContentLoaded', () => {
    if (window.__BERT_AVAILABLE__) {
      engineLabel.textContent = 'Engine: TF-IDF + BERT';
      engineBadge.classList.add('ready');
    } else {
      engineLabel.textContent = 'Engine: TF-IDF (BERT unavailable)';
      engineBadge.classList.add('ready');
    }
  });

  // ---------------- Dropzone / file handling ----------------
  dropzone.addEventListener('click', () => fileInput.click());
  dropzone.addEventListener('dragover', e => { e.preventDefault(); dropzone.classList.add('dragover'); });
  dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
  dropzone.addEventListener('drop', e => {
    e.preventDefault();
    dropzone.classList.remove('dragover');
    addFiles(e.dataTransfer.files);
  });
  fileInput.addEventListener('change', () => addFiles(fileInput.files));

  function addFiles(fileArray) {
    const allowed = ['.pdf', '.docx', '.txt'];
    Array.from(fileArray).forEach(f => {
      const ext = '.' + f.name.split('.').pop().toLowerCase();
      if (!allowed.includes(ext)) return;
      if (selectedFiles.some(sf => sf.name === f.name && sf.size === f.size)) return;
      selectedFiles.push(f);
    });
    renderFileList();
    validateForm();
  }

  function renderFileList() {
    fileListEl.innerHTML = '';
    selectedFiles.forEach((f, idx) => {
      const li = document.createElement('li');
      const sizeKb = (f.size / 1024).toFixed(0);
      li.innerHTML = `<span>${escapeHtml(f.name)} · ${sizeKb} KB</span>`;
      const removeBtn = document.createElement('button');
      removeBtn.className = 'file-remove';
      removeBtn.textContent = '✕';
      removeBtn.addEventListener('click', () => {
        selectedFiles.splice(idx, 1);
        renderFileList();
        validateForm();
      });
      li.appendChild(removeBtn);
      fileListEl.appendChild(li);
    });
  }

  function validateForm() {
    const ok = jdTextarea.value.trim().length > 20 && selectedFiles.length > 0;
    runBtn.disabled = !ok;
    errorMsg.textContent = '';
  }
  jdTextarea.addEventListener('input', validateForm);

  // ---------------- Run screening ----------------
  runBtn.addEventListener('click', runAnalysis);

  const LOADING_MESSAGES = [
    'Parsing resumes…',
    'Extracting skills with spaCy…',
    'Computing TF-IDF similarity…',
    'Scoring skill overlap…',
    'Ranking candidates…'
  ];

  async function runAnalysis() {
    errorMsg.textContent = '';
    emptyState.classList.add('hidden');
    resultsState.classList.add('hidden');
    loadingState.classList.remove('hidden');
    runBtn.disabled = true;

    let msgIdx = 0;
    loadingText.textContent = LOADING_MESSAGES[0];
    const loadingInterval = setInterval(() => {
      msgIdx = (msgIdx + 1) % LOADING_MESSAGES.length;
      loadingText.textContent = LOADING_MESSAGES[msgIdx];
    }, 900);

    const formData = new FormData();
    formData.append('job_description', jdTextarea.value.trim());
    selectedFiles.forEach(f => formData.append('resumes', f));

    try {
      const res = await fetch('/api/analyze', { method: 'POST', body: formData });
      const data = await res.json();
      clearInterval(loadingInterval);

      if (!res.ok) {
        loadingState.classList.add('hidden');
        emptyState.classList.remove('hidden');
        errorMsg.textContent = data.error || 'Something went wrong.';
        runBtn.disabled = false;
        return;
      }

      currentSessionId = data.session_id;
      renderResults(data);
    } catch (err) {
      clearInterval(loadingInterval);
      loadingState.classList.add('hidden');
      emptyState.classList.remove('hidden');
      errorMsg.textContent = 'Could not reach the server. Please try again.';
    } finally {
      runBtn.disabled = false;
    }
  }

  function renderResults(data) {
    loadingState.classList.add('hidden');
    resultsState.classList.remove('hidden');

    resultCount.textContent = `${data.results.length} candidate${data.results.length === 1 ? '' : 's'} scored`;

    const engineText = data.bert_used ? 'TF-IDF + BERT semantic matching' : 'TF-IDF matching (BERT model unavailable in this environment)';
    jdSummary.innerHTML = `<strong>${data.jd_skills.length} skill${data.jd_skills.length === 1 ? '' : 's'} detected in job description</strong> · Engine: ${engineText}${data.errors && data.errors.length ? `<br><span style="color:var(--danger)">${data.errors.length} file(s) skipped: ${data.errors.map(escapeHtml).join(' · ')}</span>` : ''}`;

    resultsList.innerHTML = '';
    const template = document.getElementById('candidateCardTemplate');

    data.results.forEach(candidate => {
      const node = template.content.cloneNode(true);

      node.querySelector('.candidate-rank').textContent = '#' + candidate.rank;
      node.querySelector('.candidate-name').textContent = candidate.candidate_name || candidate.filename;

      const metaParts = [];
      if (candidate.experience_years > 0) metaParts.push(`${candidate.experience_years} yrs experience`);
      if (candidate.education && candidate.education !== 'Not specified') metaParts.push(candidate.education);
      if (candidate.email) metaParts.push(candidate.email);
      metaParts.push(candidate.filename);
      node.querySelector('.candidate-meta').textContent = metaParts.join(' · ');

      const scoreValueEl = node.querySelector('.score-value');
      const ringFill = node.querySelector('.ring-fill');
      const circumference = 213.6;
      scoreValueEl.textContent = Math.round(candidate.final_score) + '%';
      const offset = circumference - (circumference * Math.min(candidate.final_score, 100)) / 100;
      requestAnimationFrame(() => {
        ringFill.style.strokeDashoffset = offset;
      });
      ringFill.style.strokeDashoffset = circumference; // start empty, then animate

      const textSimScore = candidate.bert_score !== null && candidate.bert_score !== undefined
        ? Math.round((candidate.tfidf_score + candidate.bert_score) / 2)
        : Math.round(candidate.tfidf_score);
      const textSimFill = node.querySelector('.text-sim');
      const textSimNum = node.querySelector('.text-sim-num');
      textSimNum.textContent = textSimScore + '%';
      requestAnimationFrame(() => { textSimFill.style.width = textSimScore + '%'; });

      const skillFill = node.querySelector('.skill-ov');
      const skillNum = node.querySelector('.skill-ov-num');
      skillNum.textContent = Math.round(candidate.skill_overlap_score) + '%';
      requestAnimationFrame(() => { skillFill.style.width = Math.round(candidate.skill_overlap_score) + '%'; });

      const matchedTags = node.querySelector('.matched-tags');
      if (candidate.matched_skills.length) {
        candidate.matched_skills.forEach(s => {
          const span = document.createElement('span');
          span.textContent = s;
          matchedTags.appendChild(span);
        });
      } else {
        matchedTags.innerHTML = '<span class="none">No overlap found</span>';
      }

      const missingTags = node.querySelector('.missing-tags');
      if (candidate.missing_skills.length) {
        candidate.missing_skills.forEach(s => {
          const span = document.createElement('span');
          span.textContent = s;
          missingTags.appendChild(span);
        });
      } else {
        missingTags.innerHTML = '<span class="none">None — full coverage</span>';
      }

      resultsList.appendChild(node);
    });
  }

  exportBtn.addEventListener('click', () => {
    if (!currentSessionId) return;
    window.location.href = `/api/export/${currentSessionId}`;
  });

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }
})();
