# Resume Screening Automation

Automates resume filtering to match candidates against job openings — built to satisfy the task brief exactly:

- **Extract skills and experience** using **spaCy** (with an NLTK-style keyword-matching fallback if the spaCy model isn't installed)
- **Match resumes to job descriptions** using **TF-IDF cosine similarity**, with optional **BERT** semantic matching layered on top when available
- **Outcome:** faster, more accurate candidate/intern selection, delivered through a ranked, filterable web dashboard
- **Data source:** any folder of resumes (PDF / DOCX / TXT) — a small sample set is included in `sample_resumes/`

---

## What's inside

```
resume_screening_automation/
├── app.py                     # Flask backend + API routes
├── modules/
│   ├── resume_parser.py       # PDF/DOCX/TXT text extraction, name/email/phone parsing
│   ├── skill_extractor.py     # spaCy-based skill & experience extraction
│   └── matcher.py             # TF-IDF + optional BERT similarity, final scoring
├── data/
│   └── skills_database.json   # Curated skills list used for matching (editable)
├── templates/index.html       # Dashboard UI
├── static/css/style.css       # Styling
├── static/js/script.js        # Frontend logic (upload, scoring animation, CSV export)
├── sample_resumes/            # 3 sample .txt resumes to try the tool immediately
└── requirements.txt
```

## How the scoring works

For each resume, the final match score (0–100%) blends two signals equally:

1. **Text similarity** — TF-IDF cosine similarity between the resume and job description (always on). If `sentence-transformers` is installed, a BERT embedding similarity is averaged in for stronger semantic matching (e.g. catching "written communication" ≈ "communication skills" even without exact keyword overlap).
2. **Skill overlap** — percentage of the job description's required skills that are also found in the resume, extracted via spaCy's PhraseMatcher against `data/skills_database.json`.

The dashboard shows both components separately, plus which required skills each candidate has and is missing.

---

## Setup (Windows / PowerShell)

```powershell
# 1. Create and activate a virtual environment
python -m venv venv
venv\Scripts\Activate.ps1

# 2. Install dependencies
pip install -r requirements.txt

# 3. Download the spaCy English model (one-time)
python -m spacy download en_core_web_sm

# 4. Run the app
python app.py
```

Then open **http://127.0.0.1:5000** in your browser.

### Optional: enable BERT semantic matching
```powershell
pip install sentence-transformers
```
No code changes needed — the app detects it automatically on the next restart and switches the "Engine" badge in the header from *TF-IDF* to *TF-IDF + BERT*. Requires internet access on first run to download the `all-MiniLM-L6-v2` model (~90 MB).

## Setup (macOS / Linux)

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python -m spacy download en_core_web_sm
python app.py
```

---

## Using the dashboard

1. Paste a job description (or click one of the **Quick start** templates — ML Intern, Full-Stack Dev, Data Analyst — to try it instantly).
2. Drag and drop resumes (PDF, DOCX, or TXT — multiple files at once), or click to browse. You can try the 3 files in `sample_resumes/` right away.
3. Click **Run Screening**.
4. Review ranked candidates: overall match %, text-similarity vs. skill-overlap breakdown, matched skills, and missing skills.
5. Click **Export CSV** to download the ranked results for sharing or record-keeping.

## Customizing the skills database

Edit `data/skills_database.json` to add/remove skills relevant to your domain — no code changes needed. Skills are grouped into categories (programming languages, web development, data science/ML, databases, cloud/DevOps, tools, soft skills, concepts) purely for display; matching works across all categories.

## Notes

- Uploaded files are processed in memory and are not permanently stored on disk.
- Max total upload size is capped at 25 MB per request (adjustable via `MAX_CONTENT_LENGTH` in `app.py`).
- If a resume's text can't be extracted (e.g. a scanned/image-only PDF with no selectable text), it's reported in the "skipped files" notice rather than silently failing.
