"""
resume_parser.py
-----------------
Handles extraction of raw text from resume files in multiple formats:
PDF, DOCX, and TXT. This is the first stage of the pipeline:

    File (.pdf/.docx/.txt) --> Raw Text --> (skill_extractor.py / matcher.py)
"""

import os
import io
import re
from PyPDF2 import PdfReader
import docx


class ResumeParser:
    """Extracts and cleans raw text content from a resume file."""

    SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".txt"}

    def parse(self, file_path: str) -> str:
        """Route the file to the correct extractor based on its extension."""
        ext = os.path.splitext(file_path)[1].lower()

        if ext == ".pdf":
            text = self._parse_pdf(file_path)
        elif ext == ".docx":
            text = self._parse_docx(file_path)
        elif ext == ".txt":
            text = self._parse_txt(file_path)
        else:
            raise ValueError(f"Unsupported file type: {ext}")

        return self._clean_text(text)

    def parse_bytes(self, file_bytes: bytes, filename: str) -> str:
        """Parse a file provided as raw bytes (used for uploaded files)."""
        ext = os.path.splitext(filename)[1].lower()

        if ext == ".pdf":
            reader = PdfReader(io.BytesIO(file_bytes))
            text = "\n".join(page.extract_text() or "" for page in reader.pages)
        elif ext == ".docx":
            document = docx.Document(io.BytesIO(file_bytes))
            text = "\n".join(p.text for p in document.paragraphs)
        elif ext == ".txt":
            text = file_bytes.decode("utf-8", errors="ignore")
        else:
            raise ValueError(f"Unsupported file type: {ext}")

        return self._clean_text(text)

    def _parse_pdf(self, file_path: str) -> str:
        reader = PdfReader(file_path)
        return "\n".join(page.extract_text() or "" for page in reader.pages)

    def _parse_docx(self, file_path: str) -> str:
        document = docx.Document(file_path)
        return "\n".join(p.text for p in document.paragraphs)

    def _parse_txt(self, file_path: str) -> str:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()

    def _clean_text(self, text: str) -> str:
        """Normalize whitespace and strip odd control characters."""
        text = re.sub(r"\r\n|\r", "\n", text)
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()

    def extract_candidate_name(self, text: str, fallback: str = "Unknown Candidate") -> str:
        """Best-effort guess of the candidate's name: usually the first non-empty line."""
        for line in text.split("\n"):
            line = line.strip()
            if 2 <= len(line.split()) <= 4 and len(line) < 50 and not any(
                ch.isdigit() for ch in line
            ) and "@" not in line:
                return line
        return fallback

    def extract_email(self, text: str) -> str:
        match = re.search(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", text)
        return match.group(0) if match else ""

    def extract_phone(self, text: str) -> str:
        match = re.search(r"(\+?\d{1,3}[\s-]?)?\(?\d{3,4}\)?[\s-]?\d{3,4}[\s-]?\d{3,4}", text)
        return match.group(0).strip() if match else ""
