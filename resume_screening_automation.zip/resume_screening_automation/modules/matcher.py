"""
matcher.py
----------
Scores how well a resume matches a job description using:

  1. TF-IDF + Cosine Similarity (scikit-learn) - always available, fast,
     works fully offline. This is the default / primary method.

  2. BERT sentence embeddings (sentence-transformers) - optional,
     semantic/contextual matching. Used automatically if the
     'sentence-transformers' package and model are available on the
     machine; otherwise the app transparently falls back to TF-IDF only
     so the feature never breaks the app.

Final match score blends: text-similarity + skill-overlap score,
so results reward both semantic relevance AND concrete keyword/skill
overlap (which recruiters usually care about most).
"""

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

try:
    from sentence_transformers import SentenceTransformer
    import numpy as np
    _BERT_AVAILABLE = True
except ImportError:
    _BERT_AVAILABLE = False


class ResumeMatcher:
    def __init__(self, use_bert: bool = True):
        self.use_bert = use_bert and _BERT_AVAILABLE
        self._bert_model = None

        if self.use_bert:
            try:
                self._bert_model = SentenceTransformer("all-MiniLM-L6-v2")
            except Exception:
                # Model weights not downloadable (e.g. no internet) -> fall back
                self.use_bert = False
                self._bert_model = None

    # ------------------------------------------------------------------
    def tfidf_similarity(self, resume_text: str, jd_text: str) -> float:
        vectorizer = TfidfVectorizer(stop_words="english")
        try:
            tfidf_matrix = vectorizer.fit_transform([jd_text, resume_text])
        except ValueError:
            return 0.0
        score = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
        return round(float(score) * 100, 2)

    def bert_similarity(self, resume_text: str, jd_text: str) -> float:
        if not self.use_bert:
            return None
        embeddings = self._bert_model.encode([jd_text, resume_text])
        score = cosine_similarity([embeddings[0]], [embeddings[1]])[0][0]
        return round(float(score) * 100, 2)

    # ------------------------------------------------------------------
    def skill_overlap_score(self, resume_skills: list, jd_skills: list) -> dict:
        """Returns overlap percentage plus matched/missing skill lists."""
        resume_set = {s.lower() for s in resume_skills}
        jd_set = {s.lower() for s in jd_skills}

        if not jd_set:
            return {"score": 0.0, "matched": [], "missing": []}

        matched = jd_set & resume_set
        missing = jd_set - resume_set
        score = round((len(matched) / len(jd_set)) * 100, 2)

        return {
            "score": score,
            "matched": sorted(matched),
            "missing": sorted(missing),
        }

    # ------------------------------------------------------------------
    def compute_match(self, resume_text: str, jd_text: str,
                       resume_skills: list, jd_skills: list) -> dict:
        """
        Combines text similarity (TF-IDF, and BERT if available) with
        skill overlap into one final weighted score (0-100).

        Weighting: 50% text similarity, 50% skill overlap.
        If BERT is available, text similarity = avg(TF-IDF, BERT).
        """
        tfidf_score = self.tfidf_similarity(resume_text, jd_text)
        bert_score = self.bert_similarity(resume_text, jd_text)

        if bert_score is not None:
            text_score = round((tfidf_score + bert_score) / 2, 2)
        else:
            text_score = tfidf_score

        overlap = self.skill_overlap_score(resume_skills, jd_skills)
        final_score = round((text_score * 0.5) + (overlap["score"] * 0.5), 2)

        return {
            "final_score": final_score,
            "tfidf_score": tfidf_score,
            "bert_score": bert_score,  # None if unavailable
            "skill_overlap_score": overlap["score"],
            "matched_skills": overlap["matched"],
            "missing_skills": overlap["missing"],
            "method_used": "TF-IDF + BERT" if bert_score is not None else "TF-IDF only",
        }
