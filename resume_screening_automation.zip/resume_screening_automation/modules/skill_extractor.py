"""
skill_extractor.py
-------------------
Uses spaCy (PhraseMatcher + NER) to extract:
  1. Technical / soft skills present in a resume, matched against a
     curated skills database (data/skills_database.json).
  2. Years of professional experience (regex-assisted, spelled-number aware).
  3. Named entities such as Organizations and Degrees (via spaCy NER),
     used to enrich the candidate profile shown in the UI.

Falls back gracefully to an NLTK-based tokenizer if the spaCy model
is unavailable, so the app never hard-crashes on a fresh environment.
"""

import json
import os
import re

try:
    import spacy
    from spacy.matcher import PhraseMatcher
    _SPACY_AVAILABLE = True
except ImportError:
    _SPACY_AVAILABLE = False


DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "skills_database.json")

_NUM_WORDS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
}


class SkillExtractor:
    def __init__(self):
        with open(DATA_PATH, "r", encoding="utf-8") as f:
            self.skills_db = json.load(f)

        # Flatten into a single list: skill -> category
        self.skill_to_category = {}
        for category, skills in self.skills_db.items():
            for skill in skills:
                self.skill_to_category[skill.lower()] = category

        self.nlp = None
        self.matcher = None

        if _SPACY_AVAILABLE:
            try:
                self.nlp = spacy.load("en_core_web_sm")
                self.matcher = PhraseMatcher(self.nlp.vocab, attr="LOWER")
                all_skills = list(self.skill_to_category.keys())
                patterns = [self.nlp.make_doc(skill) for skill in all_skills]
                self.matcher.add("SKILLS", patterns)
            except OSError:
                # Model not downloaded; extraction will fall back to regex-only mode
                self.nlp = None
                self.matcher = None

    # ------------------------------------------------------------------
    # Skill extraction
    # ------------------------------------------------------------------
    def extract_skills(self, text: str) -> dict:
        """Returns a dict of {category: [skills found]}."""
        found = set()

        if self.nlp and self.matcher:
            doc = self.nlp(text)
            matches = self.matcher(doc)
            for match_id, start, end in matches:
                span_text = doc[start:end].text
                found.add(span_text.lower())
        else:
            # Fallback: simple case-insensitive substring search
            lowered = text.lower()
            for skill in self.skill_to_category:
                if skill in lowered:
                    found.add(skill)

        # Group by category, preserving nice display casing from the DB
        display_lookup = {}
        for category, skills in self.skills_db.items():
            for skill in skills:
                display_lookup[skill.lower()] = skill

        grouped = {}
        for skill_lower in found:
            category = self.skill_to_category.get(skill_lower, "other")
            display_name = display_lookup.get(skill_lower, skill_lower.title())
            grouped.setdefault(category, []).append(display_name)

        for category in grouped:
            grouped[category] = sorted(set(grouped[category]))

        return grouped

    def flatten_skills(self, grouped_skills: dict) -> list:
        flat = []
        for skills in grouped_skills.values():
            flat.extend(skills)
        return sorted(set(flat))

    # ------------------------------------------------------------------
    # Experience extraction
    # ------------------------------------------------------------------
    def extract_experience_years(self, text: str) -> float:
        """
        Looks for patterns like '3 years of experience', 'over 5 years',
        '2+ years', 'three years experience', etc. Returns the maximum
        plausible value found, or 0 if none detected.
        """
        text_lower = text.lower()
        candidates = []

        # Digit-based: "3 years", "3+ years", "3.5 years"
        for match in re.finditer(r"(\d+(?:\.\d+)?)\s*\+?\s*years?", text_lower):
            candidates.append(float(match.group(1)))

        # Word-based: "three years"
        for word, value in _NUM_WORDS.items():
            if re.search(rf"\b{word}\b\s*\+?\s*years?", text_lower):
                candidates.append(float(value))

        candidates = [c for c in candidates if 0 < c <= 50]
        return max(candidates) if candidates else 0.0

    # ------------------------------------------------------------------
    # Named entities (organizations, education context)
    # ------------------------------------------------------------------
    def extract_organizations(self, text: str, limit: int = 8) -> list:
        if not self.nlp:
            return []
        doc = self.nlp(text[:100000])  # guard against huge documents
        orgs = []
        for ent in doc.ents:
            if ent.label_ == "ORG" and ent.text.strip() not in orgs:
                orgs.append(ent.text.strip())
            if len(orgs) >= limit:
                break
        return orgs

    def extract_education_level(self, text: str) -> str:
        text_lower = text.lower()
        levels = [
            ("phd", "PhD"),
            ("doctorate", "PhD"),
            ("master", "Master's"),
            ("m.sc", "Master's"),
            ("mba", "MBA"),
            ("bachelor", "Bachelor's"),
            ("b.sc", "Bachelor's"),
            ("bs ", "Bachelor's"),
            ("undergraduate", "Bachelor's"),
            ("intermediate", "Intermediate"),
            ("high school", "High School"),
        ]
        for keyword, label in levels:
            if keyword in text_lower:
                return label
        return "Not specified"
