"""
app.py
------
Flask backend for the Resume Screening Automation tool.

Pipeline per resume:
  1. ResumeParser   -> extract raw text from PDF/DOCX/TXT
  2. SkillExtractor -> pull skills, experience years, orgs, education (spaCy)
  3. ResumeMatcher   -> score resume against the job description
                        (TF-IDF cosine similarity, + BERT if available)

Routes:
  GET  /                 -> main UI
  POST /api/analyze      -> accepts JD text + resume files, returns ranked JSON
  GET  /api/export/<id>  -> (session-based) export last results as CSV
"""

import os
import io
import csv
import uuid
from flask import Flask, render_template, request, jsonify, send_file

from modules.resume_parser import ResumeParser
from modules.skill_extractor import SkillExtractor
from modules.matcher import ResumeMatcher

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024  # 25 MB total upload cap

parser = ResumeParser()
extractor = SkillExtractor()
matcher = ResumeMatcher(use_bert=True)

# In-memory store for the most recent analysis (per session id), used for CSV export
_LAST_RESULTS = {}


@app.route("/")
def index():
    return render_template("index.html", bert_available=matcher.use_bert)


@app.route("/api/analyze", methods=["POST"])
def analyze():
    jd_text = request.form.get("job_description", "").strip()
    if not jd_text:
        return jsonify({"error": "Job description is required."}), 400

    files = request.files.getlist("resumes")
    if not files:
        return jsonify({"error": "Please upload at least one resume."}), 400

    jd_skills_grouped = extractor.extract_skills(jd_text)
    jd_skills_flat = extractor.flatten_skills(jd_skills_grouped)

    results = []
    errors = []

    for file in files:
        if not file or not file.filename:
            continue
        ext = os.path.splitext(file.filename)[1].lower()
        if ext not in ResumeParser.SUPPORTED_EXTENSIONS:
            errors.append(f"{file.filename}: unsupported file type")
            continue

        try:
            file_bytes = file.read()
            resume_text = parser.parse_bytes(file_bytes, file.filename)

            if not resume_text or len(resume_text.strip()) < 20:
                errors.append(f"{file.filename}: no readable text found")
                continue

            resume_skills_grouped = extractor.extract_skills(resume_text)
            resume_skills_flat = extractor.flatten_skills(resume_skills_grouped)
            experience_years = extractor.extract_experience_years(resume_text)
            education = extractor.extract_education_level(resume_text)
            organizations = extractor.extract_organizations(resume_text)

            candidate_name = parser.extract_candidate_name(resume_text, fallback=file.filename)
            email = parser.extract_email(resume_text)
            phone = parser.extract_phone(resume_text)

            match = matcher.compute_match(
                resume_text, jd_text, resume_skills_flat, jd_skills_flat
            )

            results.append({
                "id": str(uuid.uuid4()),
                "filename": file.filename,
                "candidate_name": candidate_name,
                "email": email,
                "phone": phone,
                "experience_years": experience_years,
                "education": education,
                "organizations": organizations,
                "skills_grouped": resume_skills_grouped,
                "skills_flat": resume_skills_flat,
                "final_score": match["final_score"],
                "tfidf_score": match["tfidf_score"],
                "bert_score": match["bert_score"],
                "skill_overlap_score": match["skill_overlap_score"],
                "matched_skills": match["matched_skills"],
                "missing_skills": match["missing_skills"],
                "method_used": match["method_used"],
            })
        except Exception as exc:
            errors.append(f"{file.filename}: {str(exc)}")

    results.sort(key=lambda r: r["final_score"], reverse=True)
    for rank, r in enumerate(results, start=1):
        r["rank"] = rank

    session_id = str(uuid.uuid4())
    _LAST_RESULTS[session_id] = results

    return jsonify({
        "session_id": session_id,
        "jd_skills": jd_skills_flat,
        "jd_skills_grouped": jd_skills_grouped,
        "results": results,
        "errors": errors,
        "bert_used": matcher.use_bert,
    })


@app.route("/api/export/<session_id>")
def export_csv(session_id):
    results = _LAST_RESULTS.get(session_id)
    if not results:
        return jsonify({"error": "No results found for this session."}), 404

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "Rank", "Candidate Name", "File Name", "Email", "Phone",
        "Final Match Score (%)", "TF-IDF Score (%)", "BERT Score (%)",
        "Skill Overlap (%)", "Experience (yrs)", "Education",
        "Matched Skills", "Missing Skills"
    ])
    for r in results:
        writer.writerow([
            r["rank"], r["candidate_name"], r["filename"], r["email"], r["phone"],
            r["final_score"], r["tfidf_score"], r["bert_score"] or "N/A",
            r["skill_overlap_score"], r["experience_years"], r["education"],
            "; ".join(r["matched_skills"]), "; ".join(r["missing_skills"])
        ])

    mem = io.BytesIO(output.getvalue().encode("utf-8"))
    return send_file(
        mem, mimetype="text/csv", as_attachment=True,
        download_name="resume_screening_results.csv"
    )


if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0", port=5000)
